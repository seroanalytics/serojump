## library(serosolver)
devtools::load_all("~/Documents/GitHub/serosolver") ## NOTE THIS NEEDS RUNNING WITHIN THE FOREACH LOOP BELOW
library(dplyr)
library(plyr)
library(data.table)
library(ggplot2)
library(foreach)
library(doParallel)
library(coda)
setwd("~/Documents/local_data/serosolver_serojump_comparison/")

set.seed(0)
cl <- makeCluster(3)
registerDoParallel(cl)

## Time step for serosolver (i.e., divide times by this and take the floor)
tstep <- 7
## Add buffer time to front of model to build up starting titers
t_buffer <- 12

## Load in example data
dat <- readRDS("sim_data_0.1_no_COP.rds")
titre_dat1 <- as.data.frame(dat$observed_biomarker_states)
colnames(titre_dat1) <- c("individual","samples","virus","titre_true","titre")
titre_dat1 <- titre_dat1[,colnames(titre_dat1) != "titre_true"]

## Use only one titer per timestep
titre_dat1 <- titre_dat1 %>% group_by(individual,samples,virus) %>% 
  mutate(run = 1:n()) %>% ungroup() %>% filter(run == 1)
titre_dat1$group <- 1
titre_dat1$DOB <- 1
titre_dat1$group <- 1
## Convert to weeks and add 12-week
titre_dat1$samples <- floor(titre_dat1$samples/tstep) + t_buffer
strain_isolation_times <- seq(1,max(titre_dat1$samples),by=1)
titre_dat1 <- as.data.frame(titre_dat1)

## Set up par_tab for continuous data and fix unnecessary parameters
par_tab <- example_par_tab[example_par_tab$names != "phi",]
par_tab_mintitre <-par_tab[par_tab$names == "MAX_TITRE",]
par_tab_mintitre$names <- "MIN_TITRE"
par_tab_mintitre$values <- 0
par_tab <- rbind(par_tab,par_tab_mintitre)
par_tab$fixed <- 1
par_tab[par_tab$names %in% c("tau"),"values"] <- 0
par_tab[par_tab$names %in% c("mu","mu_short","wane","error"),"fixed"] <- 0

## Prior definitions
prior_func <- function(par_tab){
  ## Finds any stratification coefficient parameters
  par_names <- par_tab$names
  f <- function(pars){
    prior_p <- 0
   
    p1 <- dunif(pars["mu"],1, 2,log=TRUE)
    p2 <- dnorm(pars["mu_short"],2, 2,log=TRUE)
    #p3 <- dunif(pars["wane"], 0, 1,log=TRUE)
    p3 <- dbeta(pars["wane"],1,10,log=TRUE)
    #dnorm(pars["wane"], 0.3, 0.05,log=TRUE) 
    p4 <- dunif(pars["error"],0, 4,log=TRUE)
   
    prior_p <- prior_p + p1 + p2 + p3 + p4
    
    ## ==================================================
    prior_p
  }
}

## Dummy antigenic map, not used
antigenic_map <- data.frame(x_coord=1,y_coord=1,inf_times=strain_isolation_times)

## Run the MCMC
model_func <- create_posterior_func(par_tab=par_tab,
                                    titre_dat=titre_dat1,
                                    strain_isolation_times = strain_isolation_times,
                                    version=2)

res <- foreach(x = 1:3, .packages = c('data.table','plyr','dplyr')) %dopar% {
  
  devtools::load_all("~/Documents/GitHub/serosolver")
  
  ## Not all random starting conditions return finite likelihood, so for each chain generate random
  ## conditions until we get one with a finite likelihood
  start_prob <- -Inf
  while(!is.finite(start_prob)){
    ## Generating starting antibody kinetics parameters
    start_tab <- generate_start_tab(par_tab)
    
    ## Generate starting infection history
    start_inf <- setup_infection_histories_titre(titre_dat1, strain_isolation_times, 
                                                 space=3,titre_cutoff=4)
    start_prob <- sum(model_func(start_tab$values, start_inf)[[1]])
  }
  res <- run_MCMC(start_tab, titre_dat1,antigenic_map = antigenic_map,
                start_inf_hist=start_inf,
                filename=paste0("chains/test_",x), version=2,
                CREATE_PRIOR_FUNC = NULL,
                mcmc_pars=c(adaptive_period=1000000, iterations=1000000, 
                            inf_propn=0.5,hist_sample_prob=0.5,
                            #switch_sample=1,move_size=5, hist_opt=1,
                            save_block=10000,thin=10,thin_hist=1000),
                data_type=2)
}


## NOTE LARGE BURN IN -- CHAINS TOOK AGES TO CONVERGE
## Read in the MCMC chains and plot posteriors
all_chains <- load_mcmc_chains(location="chains",thin=1,burnin=1000000,
                               par_tab=par_tab,unfixed=TRUE,convert_mcmc=TRUE)
plot(as.mcmc.list(all_chains$theta_list_chains))

## Read in the MCMC chains for models
all_chains <- load_mcmc_chains(location="chains",thin=10,burnin=1000000,
                               par_tab=par_tab,unfixed=FALSE,convert_mcmc=FALSE)

chain <- all_chains$theta_chain
inf_chain <- all_chains$inf_chain

## Look at model estimates
apply(chain[,c("mu","mu_short","wane","error")],2,mean)

model_pred_f <- function(mu, mu_short, wane, t, tstep=1){
  preds <- matrix(0, nrow=length(mu),ncol=length(t))
  for(i in 1:length(mu)){
    preds[i,] <- mu[i] + pmax(mu_short[i]*(1-wane[i]*t/tstep),0)
  }
  preds
}

## Function to get true model trajectory
true_model_f <- function(a, b, c, t, tstep=1){
  which_early <- t < 14/tstep
  which_late <- t >= 14/tstep
  t_transform <- 14/tstep
  y <- numeric(length(t))
  y[which_early] <- log(exp(a) + exp(c))*(t[which_early]/t_transform)
  y[which_late] <- log(exp(a)*exp(-(b/t_transform)*(t[which_late]-t_transform)) + exp(c))
  y
}

ts <- seq(0,120,by=1)
preds_true <- true_model_f(mean(dat$kinetics_parameters[dat$kinetics_parameters$name == "a","value"] %>% pull(value)),
             mean(dat$kinetics_parameters[dat$kinetics_parameters$name == "b","value"] %>% pull(value)),
             mean(dat$kinetics_parameters[dat$kinetics_parameters$name == "b","value"] %>% pull(value)),
             ts,tstep=1
             )
preds <- model_pred_f(chain$mu,chain$mu_short,chain$wane,ts,tstep=7)

par(mfrow=c(1,1))
plot(apply(preds,2,mean),ylim=c(0,3),type='l')
lines(apply(preds,2,function(x) quantile(x, 0.025)),type='l',col="red")
lines(apply(preds,2,function(x) quantile(x, 0.975)),type='l',col="red")
lines(preds_true,col="purple")

## Look at infection histories
true_inf_hist <- dat$immune_histories_long
true_inf_hist <- true_inf_hist %>% mutate(t=floor(t/tstep) + t_buffer) %>%
  group_by(i,t) %>% mutate(value=sum(value)) %>% mutate(value=as.numeric(value>0)) %>% filter(value == 1)
colnames(true_inf_hist) <- c("individual","samples","value")
# Plot model predicted titres for a subset of individuals
strain_isolation_times <- antigenic_map$inf_times
test_indivs <- 1:25
p <- plot_infection_histories(chain = chain[chain$chain_no == 1,],infection_histories = inf_chain[inf_chain$chain_no == 1,],
                         strain_isolation_times = strain_isolation_times,
                              titre_dat = titre_dat1,individuals=c(test_indivs),
                         nsamp=100,
                              antigenic_map=antigenic_map,par_tab=par_tab,
                         p_ncol = 5,data_type=2)
p +
  geom_vline(data=true_inf_hist[true_inf_hist$individual %in% test_indivs,],
             aes(xintercept=samples,col="True infection"),linetype="dashed") + coord_cartesian(xlim=c(t_buffer,max(antigenic_map$inf_times))) +
  scale_color_manual("",values=c("True infection"="purple"))

## Attack rates
plot_attack_rates(infection_histories = inf_chain,
                  titre_dat = titre_dat1,
                  strain_isolation_times = strain_isolation_times) + 
  coord_cartesian(xlim=c(t_buffer,max(antigenic_map$inf_times)),ylim=c(0,0.2))

